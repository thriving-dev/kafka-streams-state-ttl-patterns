

rootProject.name="kafka-streams-state-ttl-patterns"

